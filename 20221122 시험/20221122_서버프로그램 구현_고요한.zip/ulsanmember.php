<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/reset.css">
    <link rel="stylesheet" href="./css/style.css"/>
    <script src="./js/js.js"></script>
</head>
<body>
    <div id="wrap">
        <form action="process/ulsanmember_create.php" method="post">
            <div class="title">
                    <h1 style="font-size: 21px;"> </h1>
                </div>
                <div class="email">
                    <input id="email" type="text" name="email" placeholder="이메일을 입력해 주세요.">
                    <div id="emailError" class="error"></div>
                </div>
                <div class="name">
                    <input id="name"  type="text" name="name"placeholder="이름을 입력해 주세요.">
                    <div id="nameError" class="error"></div>
                </div>
                <div class="password">
                    <input id="password" type="password" name="pw" placeholder="비밀번호를 입력해 주세요.">
                    <div id="passwordError" class="error"></div>
                </div>
                <div class="passwordCheck">
                    <input id="passwordCheck" type="password" placeholder="비밀번호를 다시 입력해 주세요.">
                    <div id="passwordCheckError" class="error"></div>
                </div>
                <div class="date">
                    <input id="year" type="text" name="year" size="3" maxlength="4" oninput="date1()"> 년
                    <input id="month" type="text" name="month"size="3" maxlength="2" oninput="date2()"> 월
                    <input id="day" type="text" name="day" size="3" maxlength="2" oninput="date3()"> 일
                    <div class="date_text">생년월일을 입력해주세요.</div>
                    <div id="dateError" class="error"></div>
                </div>

                <div class="phone">
                    <input type="text" name="tel" oninput="changePhone1()">
                </div>
                <div class="area">
                    <select id="area" name="location">
                        <option selected disabled>지역을 선택하세요.</option>
                        <option>서울</option>
                        <option>강릉</option>
                        <option>대구</option>
                        <option>울산</option>
                        <option>부산</option>
                    </select>
                    <div id="areaError" class="error"></div>
                </div>
                <div class="signUp">
                    <button id="signUpButton">가입하기</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>