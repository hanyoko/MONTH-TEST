<?php
//form에서 넘어온 데이터를 insert문을 작성 후
//mysql에 연결하여 데이터를 저장
//mysql 연결하기 mysqli_connect("호스트주소","관리자id","관리자비밀번호", "데이터베이스이름")
$conn = mysqli_connect("localhost", "root", "1234","ulsanmember");
$email = $_POST["email"];
$name = $_POST["name"];
$pw = $_POST["pw"];
$year = $_POST["year"];
$month = $_POST["month"];
$day = $_POST["day"];
$tel = $_POST["tel"];
$location = $_POST["location"];

$sql = "insert into ulsan (email, name, pw, year, month, day, tel, location) values('{$email}','{$name}','{$pw}','{$year}', '{$month}', '{$day}', '{$tel}', '{$location}')";
echo $sql;
$result = mysqli_query($conn, $sql);
if($result){
    echo "성공했습니다.";
}else {
    echo "실패했습니다.";
}
?>